The next step is within the sea. 
Some things are spoken in hex.
Not all colours are what you see.
So you must not relax.